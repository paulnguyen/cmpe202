public class Main {

	protected void print() {
	}
	
	public static void main(String[] args){
		new Main().print();
	}
}