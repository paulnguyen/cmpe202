
public class Main {

	public void print()
	{
		System.out.print("");
	}
	
	public static void main(String[] args) 
	{
		new Main().print();
	} 
		
	
}
