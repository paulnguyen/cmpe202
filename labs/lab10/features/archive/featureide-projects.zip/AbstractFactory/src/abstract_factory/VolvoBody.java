package abstract_factory;

public class VolvoBody extends VolvoPart {

}
