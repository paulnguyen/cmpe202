package abstract_factory;

public class GasEngine extends VolvoPart {

}
