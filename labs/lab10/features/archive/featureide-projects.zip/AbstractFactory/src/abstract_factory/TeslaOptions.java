package abstract_factory;

public class TeslaOptions extends TeslaPart {

}
