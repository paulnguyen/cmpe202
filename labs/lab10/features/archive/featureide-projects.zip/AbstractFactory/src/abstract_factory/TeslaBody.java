package abstract_factory;

public class TeslaBody extends TeslaPart {

}
